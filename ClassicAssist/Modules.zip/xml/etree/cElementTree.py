# Wrapper module for ElementTree

from xml.etree.ElementTree import *
